<?php 
session_start(); 
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Primer Avance del Proyecto</title>
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&family=Roboto:wght@400&display=swap"
    rel="stylesheet">
    <link href="css/gestionar_categorias.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="js/menu.js"></script>
</head>

<body>

    <header class="encabezado">
        <nav class="navbar">
            <img src="img/logo.png" alt="Logo del Proyecto" class="encabezado__logo">
            <span class="hamburger" onclick="toggleMenu()">☰</span>
            <ul class="menu-items">
                <li><a href="index.php">Inicio</a></li>
                <li>
                    <a href="#item2">Acerca de nosotros</a>
                    <ul class="submenu">
                        <li><a href="objetivos.php">Objetivos</a></li>
                        <li><a href="plan_trabajo.php">Plan de trabajo</a></li>
                    </ul>
                </li>
                <li><a href="servicios.php">Servicios</a></li>
                <li>
                    <a href="#item2">Compra</a>
                    <ul class="submenu">
                        <li><a href="productos.php">Productos</a></li>
                        <li><a href="gestionar_productos.php">Gestionar Productos</a></li>
                        <li><a href="gestionar_categorias.php">Gestionar Categorias</a></li>
                    </ul>
                </li>
                <li><a href="contacto.php">Contacto</a></li>
            </ul>
            <div class="cart">
                <button class="carrito__boton" onclick="abrirCarrito()"><i class="fa-solid fa-cart-shopping cart-icon"></i></button>
                <span>0</span> <!-- Número de elementos en el carrito -->
            </div>
            <div class="encabezado__login">
                <?php 
                    if (!isset($_SESSION['logueado'])): ?>
                        <div class="contenedor-acceso">
                            <a href="login.php?redirect=index.php" class="boton-login">Iniciar sesión</a>
                            <a href="registro.php" class="boton-registro">Registrarse</a>
                        </div>
                    <?php else: ?>
                        <div class="contenedor-bienvenida">
                            <p>Hola! <strong><?php echo htmlspecialchars($_SESSION['nombre'], ENT_QUOTES, 'UTF-8'); ?></strong></p>
                            <a href="logout.php" class="boton-logout">Cerrar sesión</a>
                        </div>
                    <?php endif; 
                ?>

            </div>
        </nav>        
    </header>


    <br>
    <div class="contenedor contenedor--inicio">
        <div class="intro">
            <h3 class="subtitulo">Bienvenidos a nuestra Empresa de Software</h3>
            <p class="texto">Soluciones innovadoras para tus necesidades de software</p>
        </div>

        <div class="seccion-video">
            <iframe class="seccion-video__iframe" width="560" height="315" src="https://www.youtube.com/embed/fzWzPXEhPvA?si=zfU8nwCiyoXoAc9p" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </div>

        <div class="content">
            <h2 class="subtitulo">Nuestros Servicios</h2>
            <p class="texto">Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero harum ipsa sunt, maiores velit nam itaque iste qui dignissimos quae. Eaque numquam, soluta accusantium qui cumque asperiores blanditiis aspernatur molestiae veritatis quos a voluptas itaque rem. Earum quasi corporis, qui labore laborum odit laboriosam minima ipsa aliquid voluptatum cupiditate! Expedita, enim omnis tempora placeat necessitatibus maiores qui iste similique quibusdam accusamus, eum ea? Consectetur commodi, repellendus veniam amet earum iure reiciendis nobis debitis, quos magnam, deleniti itaque dolores culpa dolorem vel sit animi ipsum voluptas facilis distinctio sed. Laudantium assumenda sed quasi ab consequatur debitis animi accusamus, sequi at cupiditate.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod rem doloremque ea error iusto saepe, voluptatibus, vel earum consequuntur aperiam ut. Aut commodi quam maxime voluptate, iusto sequi, officia quos aperiam, voluptatibus incidunt velit optio nihil quasi qui facilis. Consequatur error aperiam sunt deserunt voluptatibus, nam excepturi atque qui modi cum? Pariatur facere et illum hic in facilis asperiores impedit alias eligendi ut est quaerat, expedita, adipisci error vitae. Ducimus provident sit maxime aut accusamus. Sed officiis molestias perspiciatis repellendus mollitia iste officia ratione. Suscipit quisquam corrupti iure debitis recusandae necessitatibus laborum voluptatem numquam accusamus quis. Delectus illo sit itaque?
        </p>
        </div>
    </div>
    <footer class="pie-pagina">
        <div class="pie-pagina__contenedor">
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Sobre Nosotros</h3>
                <p class="pie-pagina__texto">Somos una empresa líder en soluciones tecnológicas, comprometida con la innovación y la excelencia en cada proyecto.</p>
            </div>
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Enlaces Rápidos</h3>
                <ul class="pie-pagina__lista">
                    <li><a href="index.php" class="pie-pagina__enlace">Inicio</a></li>
                    <li><a href="servicios.php" class="pie-pagina__enlace">Servicios</a></li>
                    <li><a href="objetivos.php" class="pie-pagina__enlace">Objetivos</a></li>
                    <li><a href="productos.php" class="pie-pagina__enlace">Productos</a></li>
                    <li><a href="contacto.php" class="pie-pagina__enlace">Contacto</a></li>
                </ul>
            </div>
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Contacto</h3>
                <p class="pie-pagina__texto">Email: info@tuempresa.com</p>
                <p class="pie-pagina__texto">Teléfono: (123) 456-7890</p>
                <p class="pie-pagina__texto">Dirección: Calle Principal 123, Ciudad</p>
            </div>
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Síguenos</h3>
                <div class="pie-pagina__redes-sociales">
                    <a href="#" class="pie-pagina__red-social">Facebook</a>
                    <a href="#" class="pie-pagina__red-social">Twitter</a>
                    <a href="#" class="pie-pagina__red-social">LinkedIn</a>
                    <a href="#" class="pie-pagina__red-social">Instagram</a>
                </div>
            </div>
        </div>
        <div class="pie-pagina__derechos">
            <p>&copy; 2024 Tu Empresa. Todos los derechos reservados.</p>
        </div>
    </footer>

</body>

</html>

<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empresa Electrónicos</title>
    <link href="css/menu.css" rel="stylesheet" type="text/css"/>
</head>
<body>
    <nav class="menu">
        <ul>
            <li><a href="index.php">Inicio</a></li>
            <li><a href="gestionar_categorias.php">Categorías</a></li>
            <li><a href="gestionar_productos.php">Productos</a></li>
        </ul>
    </nav>
    <div class="content">
        <!-- Aquí se cargará el contenido de cada página -->
    </div>
</body>
</html>



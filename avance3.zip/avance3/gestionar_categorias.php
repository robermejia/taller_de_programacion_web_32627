<?php 
session_start(); 
?>
<?php
// Conexión a la base de datos
$conn = new mysqli('localhost', 'root', 'admin', 'empresa_electronicos');

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Lógica para CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) { // Agregar categoría
        $nombre = $_POST['nombre'];
        $conn->query("INSERT INTO categorias (nombre_categoria) VALUES ('$nombre')");
    } elseif (isset($_POST['edit'])) { // Editar categoría
        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $conn->query("UPDATE categorias SET nombre_categoria='$nombre' WHERE id_categoria='$id'");
    } elseif (isset($_POST['delete'])) { // Eliminar categoría
        $id = $_POST['id'];
        $conn->query("DELETE FROM categorias WHERE id_categoria='$id'");
    }
}

// Consultar categorías
$categorias = $conn->query("SELECT * FROM categorias");
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Primer Avance del Proyecto</title>
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link href="css/gestionar_categorias.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&family=Roboto:wght@400&display=swap"
    rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="js/menu.js"></script>
</head>

<body>

    <header class="encabezado">
        <nav class="navbar">
            <img src="img/logo.png" alt="Logo del Proyecto" class="encabezado__logo">
            <span class="hamburger" onclick="toggleMenu()">☰</span>
            <ul class="menu-items">
                <li><a href="index.php">Inicio</a></li>
                <li>
                    <a href="#item2">Acerca de nosotros</a>
                    <ul class="submenu">
                        <li><a href="objetivos.php">Objetivos</a></li>
                        <li><a href="plan_trabajo.php">Plan de trabajo</a></li>
                    </ul>
                </li>
                <li><a href="servicios.php">Servicios</a></li>
                <li>
                    <a href="#item2">Compra</a>
                    <ul class="submenu">
                        <li><a href="productos.php">Productos</a></li>
                        <li><a href="gestionar_productos.php">Gestionar Productos</a></li>
                        <li><a href="gestionar_categorias.php">Gestionar Categorias</a></li>
                    </ul>
                </li>
                <li><a href="contacto.php">Contacto</a></li>
            </ul>
            <div class="cart">
                <button class="carrito__boton" onclick="abrirCarrito()"><i class="fa-solid fa-cart-shopping cart-icon"></i></button>
                <span>0</span> <!-- Número de elementos en el carrito -->
            </div>
            <div class="encabezado__login">
                <?php 
                    if (!isset($_SESSION['logueado'])): ?>
                        <div class="contenedor-acceso">
                            <a href="login.php?redirect=index.php" class="boton-login">Iniciar sesión</a>
                            <a href="registro.php" class="boton-registro">Registrarse</a>
                        </div>
                    <?php else: ?>
                        <div class="contenedor-bienvenida">
                            <p>Hola! <strong><?php echo htmlspecialchars($_SESSION['nombre'], ENT_QUOTES, 'UTF-8'); ?></strong></p>
                            <a href="logout.php" class="boton-logout">Cerrar sesión</a>
                        </div>
                    <?php endif; 
                ?>

            </div>
        </nav>        
    </header>


    <div class="categorias-container">
        <h1 class="categorias-titulo">Gestión de Categorías</h1>

        <!-- Formulario para agregar y editar categorías -->
        <form method="POST" class="categorias-form">
            <input type="hidden" name="id" id="categoria-id">
            <label for="categoria-nombre" class="categorias-label">Nombre de la Categoría:</label>
            <input type="text" name="nombre" id="categoria-nombre" class="categorias-input" required>

            <div class="categorias-botones">
                <button type="submit" name="add" class="categorias-boton agregar">Agregar</button>
                <button type="submit" name="edit" class="categorias-boton editar">Editar</button>
            </div>
        </form>

        <!-- Tabla de categorías -->
        <div class="categorias-tabla-wrapper">
            <table class="categorias-tabla">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $categorias->fetch_assoc()): ?>
                        <tr>
                            <td data-label="ID"><?= $row['id_categoria'] ?></td>
                            <td data-label="Nombre"><?= $row['nombre_categoria'] ?></td>
                            <td data-label="Acciones">
                                <button onclick="fillForm(<?= htmlspecialchars(json_encode($row)) ?>)" class="categorias-boton editar">Editar</button>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="id" value="<?= $row['id_categoria'] ?>">
                                    <button type="submit" name="delete" class="categorias-boton eliminar">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Llenar el formulario para edición
        function fillForm(categoria) {
            document.getElementById('categoria-id').value = categoria.id_categoria;
            document.getElementById('categoria-nombre').value = categoria.nombre_categoria;
        }
    </script>

   
    <footer class="pie-pagina">
        <div class="pie-pagina__contenedor">
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Sobre Nosotros</h3>
                <p class="pie-pagina__texto">Somos una empresa líder en soluciones tecnológicas, comprometida con la innovación y la excelencia en cada proyecto.</p>
            </div>
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Enlaces Rápidos</h3>
                <ul class="pie-pagina__lista">
                    <li><a href="index.php" class="pie-pagina__enlace">Inicio</a></li>
                    <li><a href="servicios.php" class="pie-pagina__enlace">Servicios</a></li>
                    <li><a href="objetivos.php" class="pie-pagina__enlace">Objetivos</a></li>
                    <li><a href="productos.php" class="pie-pagina__enlace">Productos</a></li>
                    <li><a href="contacto.php" class="pie-pagina__enlace">Contacto</a></li>
                </ul>
            </div>
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Contacto</h3>
                <p class="pie-pagina__texto">Email: info@tuempresa.com</p>
                <p class="pie-pagina__texto">Teléfono: (123) 456-7890</p>
                <p class="pie-pagina__texto">Dirección: Calle Principal 123, Ciudad</p>
            </div>
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Síguenos</h3>
                <div class="pie-pagina__redes-sociales">
                    <a href="#" class="pie-pagina__red-social">Facebook</a>
                    <a href="#" class="pie-pagina__red-social">Twitter</a>
                    <a href="#" class="pie-pagina__red-social">LinkedIn</a>
                    <a href="#" class="pie-pagina__red-social">Instagram</a>
                </div>
            </div>
        </div>
        <div class="pie-pagina__derechos">
            <p>&copy; 2024 Tu Empresa. Todos los derechos reservados.</p>
        </div>
    </footer>

</body>

</html>
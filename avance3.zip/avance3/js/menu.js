/*Menú*/ 
function toggleMenu() {
    document.querySelector('.navbar').classList.toggle('open');
}
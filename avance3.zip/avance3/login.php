<?php
include('config.php');
session_start();
$redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'index.php';

$mensaje = ""; // Variable para almacenar el mensaje

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $contrasena = $_POST['contrasena'];

    if (!empty($email) && !empty($contrasena)) {
        $sql = "SELECT * FROM usuarios WHERE email = '$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($contrasena, $row['contrasena'])) {
                $_SESSION['nombre'] = $row['nombre'];
                $_SESSION['logueado'] = true;

                header("Location: $redirect");
                exit();
            } else {
                $mensaje = "Contraseña incorrecta";
            }
        } else {
            $mensaje = "El email no está registrado";
        }
    } else {
        $mensaje = "Por favor, ingrese todos los campos";
    }
}
?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="js/menu.js"></script>
</head>
</head>

<body>
    <header class="encabezado">
        <nav class="navbar">
            <img src="img/logo.png" alt="Logo del Proyecto" class="encabezado__logo">
            <span class="hamburger" onclick="toggleMenu()">☰</span>
            <ul class="menu-items">
                <li><a href="index.php">Inicio</a></li>
                <li>
                    <a href="#item2">Acerca de nosotros</a>
                    <ul class="submenu">
                        <li><a href="objetivos.php">Objetivos</a></li>
                        <li><a href="plan_trabajo.php">Plan de trabajo</a></li>
                    </ul>
                </li>
                <li><a href="servicios.php">Servicios</a></li>
                <li>
                    <a href="#item2">Compra</a>
                    <ul class="submenu">
                        <li><a href="productos.php">Productos</a></li>
                        <li><a href="gestionar_productos.php">Gestionar Productos</a></li>
                        <li><a href="gestionar_categorias.php">Gestionar Categorias</a></li>
                    </ul>
                </li>
                <li><a href="contacto.php">Contacto</a></li>
            </ul>
            <div class="cart">
                <button class="carrito__boton" onclick="abrirCarrito()"><i class="fa-solid fa-cart-shopping cart-icon"></i></button>
                <span>0</span> <!-- Número de elementos en el carrito -->
            </div>
            <div class="encabezado__login">
                <?php 
                    if (!isset($_SESSION['logueado'])): ?>
                        <div class="contenedor-acceso">
                            <a href="login.php?redirect=index.php" class="boton-login">Iniciar sesión</a>
                            <a href="registro.php" class="boton-registro">Registrarse</a>
                        </div>
                    <?php else: ?>
                        <div class="contenedor-bienvenida">
                            <p>Hola! <strong><?php echo htmlspecialchars($_SESSION['nombre'], ENT_QUOTES, 'UTF-8'); ?></strong></p>
                            <a href="logout.php" class="boton-logout">Cerrar sesión</a>
                        </div>
                    <?php endif; 
                ?>

            </div>
        </nav>        
    </header>


    <div class="contenedor-login">
        <h2 class="titulo-login">Iniciar sesión</h2>

        <!-- Mostrar mensaje si existe -->
        <?php if (!empty($mensaje)) : ?>
            <div class="mensaje 
                <?php echo (strpos($mensaje, 'incorrecta') !== false || strpos($mensaje, 'registrado') !== false) ? 'error' : 'exito'; ?>">
                <?php echo $mensaje; ?>
            </div>
        <?php endif; ?>

        <form action="login.php?redirect=<?php echo $redirect; ?>" method="POST">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>

            <label for="contrasena">Contraseña:</label>
            <input type="password" name="contrasena" id="contrasena" required>

            <button type="submit" class="login_submit" name="login">Iniciar sesión</button>
        </form>
        <p class="login_p">¿No tienes cuenta? <a href="registro.php">Regístrate aquí</a></p>
    </div>

    <footer class="pie-pagina">
        <div class="pie-pagina__contenedor">
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Sobre Nosotros</h3>
                <p class="pie-pagina__texto">Somos una empresa líder en soluciones tecnológicas, comprometida con la innovación y la excelencia en cada proyecto.</p>
            </div>
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Enlaces Rápidos</h3>
                <ul class="pie-pagina__lista">
                    <li><a href="index.php" class="pie-pagina__enlace">Inicio</a></li>
                    <li><a href="servicios.php" class="pie-pagina__enlace">Servicios</a></li>
                    <li><a href="objetivos.php" class="pie-pagina__enlace">Objetivos</a></li>
                    <li><a href="productos.php" class="pie-pagina__enlace">Productos</a></li>
                    <li><a href="contacto.php" class="pie-pagina__enlace">Contacto</a></li>
                </ul>
            </div>
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Contacto</h3>
                <p class="pie-pagina__texto">Email: info@tuempresa.com</p>
                <p class="pie-pagina__texto">Teléfono: (123) 456-7890</p>
                <p class="pie-pagina__texto">Dirección: Calle Principal 123, Ciudad</p>
            </div>
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Síguenos</h3>
                <div class="pie-pagina__redes-sociales">
                    <a href="#" class="pie-pagina__red-social">Facebook</a>
                    <a href="#" class="pie-pagina__red-social">Twitter</a>
                    <a href="#" class="pie-pagina__red-social">LinkedIn</a>
                    <a href="#" class="pie-pagina__red-social">Instagram</a>
                </div>
            </div>
        </div>
        <div class="pie-pagina__derechos">
            <p>&copy; 2024 Tu Empresa. Todos los derechos reservados.</p>
        </div>
    </footer>
</body>

</html>
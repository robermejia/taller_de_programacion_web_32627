<?php 
session_start(); 
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Primer Avance del Proyecto</title>
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&family=Roboto:wght@400&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="js/menu.js"></script>
</head>

<body>

    <header class="encabezado">
        <nav class="navbar">
            <img src="img/logo.png" alt="Logo del Proyecto" class="encabezado__logo">
            <span class="hamburger" onclick="toggleMenu()">☰</span>
            <ul class="menu-items">
                <li><a href="index.php">Inicio</a></li>
                <li>
                    <a href="#item2">Acerca de nosotros</a>
                    <ul class="submenu">
                        <li><a href="objetivos.php">Objetivos</a></li>
                        <li><a href="plan_trabajo.php">Plan de trabajo</a></li>
                    </ul>
                </li>
                <li><a href="servicios.php">Servicios</a></li>
                <li>
                    <a href="#item2">Compra</a>
                    <ul class="submenu">
                        <li><a href="productos.php">Productos</a></li>
                        <li><a href="gestionar_productos.php">Gestionar Productos</a></li>
                        <li><a href="gestionar_categorias.php">Gestionar Categorias</a></li>
                    </ul>
                </li>
                <li><a href="contacto.php">Contacto</a></li>
            </ul>
            <div class="cart">
                <button class="carrito__boton" onclick="abrirCarrito()"><i class="fa-solid fa-cart-shopping cart-icon"></i></button>
                <span>0</span> <!-- Número de elementos en el carrito -->
            </div>
            <div class="encabezado__login">
                <?php 
                    if (!isset($_SESSION['logueado'])): ?>
                        <div class="contenedor-acceso">
                            <a href="login.php?redirect=index.php" class="boton-login">Iniciar sesión</a>
                            <a href="registro.php" class="boton-registro">Registrarse</a>
                        </div>
                    <?php else: ?>
                        <div class="contenedor-bienvenida">
                            <p>Hola! <strong><?php echo htmlspecialchars($_SESSION['nombre'], ENT_QUOTES, 'UTF-8'); ?></strong></p>
                            <a href="logout.php" class="boton-logout">Cerrar sesión</a>
                        </div>
                    <?php endif; 
                ?>

            </div>
        </nav>        
    </header>


    <div class="contenedor contenedor--general">
        <div class="contenedor--descripcion">
            <h3 class="subtitulo">Objetivos</h3>
            <p class="texto texto--justificado">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam dolor obcaecati inventore deleniti dolores quaerat accusantium corporis cum placeat ab repudiandae minima, vitae eaque rem labore quibusdam fugiat aut reiciendis voluptates culpa delectus. Cupiditate, magnam exercitationem facilis voluptatem rem, nam omnis, sint quis sapiente error placeat officia aliquam vitae atque et architecto fuga vero. Magnam dolor, libero a magni aspernatur quaerat tenetur sint et nihil nulla quis obcaecati blanditiis earum corporis commodi ducimus alias quam quia cum tempora facere! Facilis deserunt dolorem molestiae? Optio, harum vero! Eius asperiores sit reiciendis impedit exercitationem quos libero suscipit animi odit accusantium explicabo, laborum ipsum incidunt. Dolorem beatae, in laborum at pariatur vel labore incidunt hic amet sapiente magni voluptate aliquam itaque! Quod distinctio facilis porro et laudantium consequuntur id aliquam dolor illum adipisci hic mollitia reiciendis ratione eveniet voluptatibus, itaque impedit commodi maxime consectetur! Veniam harum odit expedita recusandae odio quibusdam vero adipisci earum cumque, velit illo dolorum optio totam fugiat, aperiam ipsa sequi dolorem est veritatis nemo in aspernatur dicta id sit. Dolorem odio cumque commodi incidunt, fugiat error atque quidem expedita accusantium quam rerum non provident molestias distinctio ipsa consectetur vitae amet nam? Nemo saepe sunt quis ab corrupti modi numquam?</p>
            <div class="imagen-contenedor">
                <img src="img/empresa/brief.jpg" alt="Imagen de objetivos" class="imagen imagen--centrada">
            </div>
            <p class="texto texto--justificado">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam dolor obcaecati inventore deleniti dolores quaerat accusantium corporis cum placeat ab repudiandae minima, vitae eaque rem labore quibusdam fugiat aut reiciendis voluptates culpa delectus. Cupiditate, magnam exercitationem facilis voluptatem rem, nam omnis, sint quis sapiente error placeat officia aliquam vitae atque et architecto fuga vero. Magnam dolor, libero a magni aspernatur quaerat tenetur sint et nihil nulla quis obcaecati blanditiis earum corporis commodi ducimus alias quam quia cum tempora facere! Facilis deserunt dolorem molestiae? Optio, harum vero! Eius asperiores sit reiciendis impedit exercitationem quos libero suscipit animi odit accusantium explicabo, laborum ipsum incidunt. Dolorem beatae, in laborum at pariatur vel labore incidunt hic amet sapiente magni voluptate aliquam itaque! Quod distinctio facilis porro et laudantium consequuntur id aliquam dolor illum adipisci hic mollitia reiciendis ratione eveniet voluptatibus, itaque impedit commodi maxime consectetur! Veniam harum odit expedita recusandae odio quibusdam vero adipisci earum cumque, velit illo dolorum optio totam fugiat, aperiam ipsa sequi dolorem est veritatis nemo in aspernatur dicta id sit. Dolorem odio cumque commodi incidunt, fugiat error atque quidem expedita accusantium quam rerum non provident molestias distinctio ipsa consectetur vitae amet nam? Nemo saepe sunt quis ab corrupti modi numquam?</p>
        </div>
    </div>
    <footer class="pie-pagina">
        <div class="pie-pagina__contenedor">
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Sobre Nosotros</h3>
                <p class="pie-pagina__texto">Somos una empresa líder en soluciones tecnológicas, comprometida con la innovación y la excelencia en cada proyecto.</p>
            </div>
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Enlaces Rápidos</h3>
                <ul class="pie-pagina__lista">
                    <li><a href="index.php" class="pie-pagina__enlace">Inicio</a></li>
                    <li><a href="servicios.php" class="pie-pagina__enlace">Servicios</a></li>
                    <li><a href="objetivos.php" class="pie-pagina__enlace">Objetivos</a></li>
                    <li><a href="productos.php" class="pie-pagina__enlace">Productos</a></li>
                    <li><a href="contacto.php" class="pie-pagina__enlace">Contacto</a></li>
                </ul>
            </div>
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Contacto</h3>
                <p class="pie-pagina__texto">Email: info@tuempresa.com</p>
                <p class="pie-pagina__texto">Teléfono: (123) 456-7890</p>
                <p class="pie-pagina__texto">Dirección: Calle Principal 123, Ciudad</p>
            </div>
            <div class="pie-pagina__seccion">
                <h3 class="pie-pagina__titulo">Síguenos</h3>
                <div class="pie-pagina__redes-sociales">
                    <a href="#" class="pie-pagina__red-social">Facebook</a>
                    <a href="#" class="pie-pagina__red-social">Twitter</a>
                    <a href="#" class="pie-pagina__red-social">LinkedIn</a>
                    <a href="#" class="pie-pagina__red-social">Instagram</a>
                </div>
            </div>
        </div>
        <div class="pie-pagina__derechos">
            <p>&copy; 2024 Tu Empresa. Todos los derechos reservados.</p>
        </div>
    </footer>

</body>

</html>